async function pesquisarcidade(){
    const cidade = document.getElementById('cidade').value;
    
    const apikey = 'f4c4ff8d2622fd33ceb43046a2f2507b';
    const url = (`https://api.openweathermap.org/data/2.5/weather?q=${cidade}&appid=${apikey}&lang=pt_br&units=metric`);
    
    
    
    fetch(url)
    .then(response => {
      if (!response.ok) {
        throw new Error('Cidade não encontrada');
      }
      return response.json();
    })
    .then(data => {
      // Aqui você chama a função que mostra o resultado
      divresultado(data);
    })
    .catch(error => {
      console.error('Erro:', error);
    });

    function divresultado(data){
    
  
    const resultado = document.getElementById('divResultado');
      resultado.querySelector('.tempcidade').textContent = data.name;
      resultado.querySelector('.temperatura').textContent = `${data.main.temp}°C`;
      resultado.querySelector('.tempo').textContent = data.weather[0].description;
      resultado.querySelector('.umidade').textContent = `${data.main.humidity}%`;
    }
}