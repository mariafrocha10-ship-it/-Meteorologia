const apiKey = "SUA_CHAVE_API_AQUI"; // Substitua pela sua chave da OpenWeatherMap

document.getElementById("searchBtn").addEventListener("click", () => {
  const city = document.getElementById("cityInput").value.trim();
  if (city === "") {
    alert("Digite o nome de uma cidade!");
    return;
  }
  getWeather(city);
});

async function getWeather(city) {
  try {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&lang=pt_br&units=metric`;
    const response = await fetch(url);

    if (!response.ok) throw new Error("Cidade não encontrada!");

    const data = await response.json();
    showWeather(data);
  } catch (err) {
    alert(err.message);
  }
}

function showWeather(data) {
  const weatherBox = document.getElementById("weatherBox");
  const icon = data.weather[0].icon;

  document.getElementById("cityName").textContent = `${data.name}, ${data.sys.country}`;
  document.getElementById("temperature").textContent = `${Math.round(data.main.temp)}°C`;
  document.getElementById("description").textContent = data.weather[0].description;
  document.getElementById("humidity").textContent = `Umidade: ${data.main.humidity}%`;
  document.getElementById("wind").textContent = `Vento: ${data.wind.speed} m/s`;
  document.getElementById("weatherIcon").src = `https://openweathermap.org/img/wn/${icon}@2x.png`;

  weatherBox.classList.remove("hidden");

  // 🎨 Efeito visual baseado na temperatura
  const temp = data.main.temp;
  if (temp <= 15) {
    document.body.style.background = "linear-gradient(135deg,rgb(207, 69, 238),rgb(181, 44, 227))";
  } else if (temp <= 25) {
    document.body.style.background = "linear-gradient(135deg,rgb(132, 107, 167),rgb(222, 171, 237))";
  } else {
    document.body.style.background = "linear-gradient(135deg,rgb(146, 69, 214),rgb(104, 31, 160))";
  }
}

